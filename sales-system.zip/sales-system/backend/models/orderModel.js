const db = require("../config/db");



// 💳 Захиалга үүсгэх
exports.createOrder = async (userId, addressId, totalPrice, paymentMethod, cartItems) => {
  return new Promise(async (resolve, reject) => {
    db.beginTransaction(async (err) => {
      if (err) return reject(err);

      try {
        // 1️⃣ Төлбөр үүсгэх
        const [paymentResult] = await db.promise().query(
          `INSERT INTO payments (payment_method, amount, payment_status)
           VALUES (?, ?, 'Хүлээгдэж байна')`,
          [paymentMethod, totalPrice]
        );
        const paymentId = paymentResult.insertId;

        // 2️⃣ Захиалга үүсгэх
        const [orderResult] = await db.promise().query(
          `INSERT INTO orders (user_id, address_id, total_price, payment_id, order_status)
           VALUES (?, ?, ?, ?, 'Хүлээгдэж байна')`,
          [userId, addressId, totalPrice, paymentId]
        );
        const orderId = orderResult.insertId;

        // 3️⃣ Төлбөрт order_id-г update хийх
        await db.promise().query(
          `UPDATE payments SET order_id = ? WHERE payment_id = ?`,
          [orderId, paymentId]
        );

        // 4️⃣ Захиалгын бараанууд нэмэх + үлдэгдэл хасах
        for (const item of cartItems) {
          // 🔹 Захиалгын бараа нэмэх
          await db.promise().query(
            `INSERT INTO order_items (order_id, product_id, quantity, price)
             VALUES (?, ?, ?, ?)`,
            [orderId, item.product_id, item.quantity, item.price]
          );

          // ✅ Барааны үлдэгдэл хасах хэсэг — энд яг энэ мөрийг нэмнэ
          await db.promise().query(
            `UPDATE products 
             SET stock = GREATEST(stock - ?, 0)
             WHERE id = ?`,
            [item.quantity, item.product_id]
          );
        }

        // 5️⃣ Transaction commit
        db.commit((err) => {
          if (err) return db.rollback(() => reject(err));
          resolve({ orderId, paymentId });
        });
      } catch (error) {
        db.rollback(() => reject(error));
      }
    });
  });
};



exports.getUserOrdersWithItems = async (userId) => {
  const [rows] = await db.promise().query(
    `
    SELECT
      o.order_id,
      o.total_price,
      o.order_status,
      o.created_at,
      a.city, a.district, a.subdistrict, a.address_detail,
      p.payment_method, p.payment_status,

      oi.item_id, oi.product_id, oi.quantity, oi.price AS item_price,
      pr.name AS product_name,

      /* ✅ Гол зураг: is_main=1 байвал тэр, үгүй бол эхний зураг */
      COALESCE(
        pim.image_url,
        (SELECT pi2.image_url
         FROM product_images pi2
         WHERE pi2.product_id = pr.id
         ORDER BY pi2.is_main DESC, pi2.id ASC
         LIMIT 1)
      ) AS main_image

    FROM orders o
    LEFT JOIN addresses a ON a.address_id = o.address_id
    LEFT JOIN payments p ON p.payment_id = o.payment_id
    LEFT JOIN order_items oi ON oi.order_id = o.order_id
    LEFT JOIN products pr ON pr.id = oi.product_id
    LEFT JOIN product_images pim
      ON pim.product_id = pr.id AND pim.is_main = 1

    WHERE o.user_id = ?
    ORDER BY o.created_at DESC, oi.item_id ASC
    `,
    [userId]
  );

  // ➜ Мөрүүдийг захиалга бүрээр бүлэглэж, item жагсаалт үүсгэнэ
  const byOrder = new Map();

  for (const r of rows) {
    if (!byOrder.has(r.order_id)) {
      byOrder.set(r.order_id, {
        order_id: r.order_id,
        created_at: r.created_at,
        total_price: Number(r.total_price || 0),
        order_status: r.order_status,
        address: {
          city: r.city,
          district: r.district,
          subdistrict: r.subdistrict,
          address_detail: r.address_detail,
        },
        payment: {
          method: r.payment_method,
          status: r.payment_status,
        },
        items: [],
      });
    }

    if (r.item_id) {
      byOrder.get(r.order_id).items.push({
        item_id: r.item_id,
        product_id: r.product_id,
        name: r.product_name,
        qty: r.quantity,
        price: Number(r.item_price || 0),
        // static serve: app.use("/uploads", express.static("uploads"))
        image: r.main_image ? `/${String(r.main_image).replace(/^\/+/, "")}` : null,
      });
    }
  }

  return Array.from(byOrder.values());
};

