// models/userModel.js
const db = require("../config/db");

const User = {
  // Имэйл бүртгэлтэй эсэхийг шалгах
  findByEmail: (email, callback) => {
    db.query("SELECT * FROM users WHERE email = ?", [email], callback);
  },
  // → ID-аар хайх
  findById: (id, callback) => {
    const sql = "SELECT id, name, email, phone FROM users WHERE id = ?";
    db.query(sql, [id], callback);
  },

  // Шинэ хэрэглэгч нэмэх
  create: (userData, callback) => {
    const { name, email, phone, password } = userData;
    db.query(
      "INSERT INTO users (name, email, phone, password) VALUES (?, ?, ?, ?)",
      [name, email, phone, password],
      callback
    );
  },
};


module.exports = User;
