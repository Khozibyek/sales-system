const db = require("../config/db");

const Product = {
  // 🔹 Бүх бараа + tag-уудтай нь авах
  getAll: (callback) => {
  const sql = `
    SELECT 
      p.id, 
      p.name, 
      p.price, 
      p.discount_percent,
      p.stock,
      (p.stock = 0) AS out_of_stock,
      (p.price * (1 - p.discount_percent / 100)) AS discounted_price,
      p.is_featured,
      (
        SELECT pi.image_url 
        FROM product_images pi 
        WHERE pi.product_id = p.id AND pi.is_main = 1 
        LIMIT 1
      ) AS main_image,

      b.name AS brand,
      c.name AS category,
      m.name AS model,

      TIMESTAMPDIFF(DAY, p.created_at, NOW()) AS days_since_added
    FROM products p
    LEFT JOIN brands b ON p.brand_id = b.id
    LEFT JOIN categories c ON p.category_id = c.id
    LEFT JOIN models m ON p.model_id = m.id
    ORDER BY p.created_at DESC;
  `;
  db.query(sql, callback);
},


  // 🔹 Нэг бараа авах
getById: (id, callback) => {
  const sql = `
    SELECT 
      p.id,
      p.name,
      p.description,
      p.price,
      p.discount_percent,
      p.stock,
      p.is_featured,
      p.created_at,
      b.name AS brand,
      c.name AS category,
      m.name AS model,
      GROUP_CONCAT(DISTINCT pi.image_url ORDER BY pi.id SEPARATOR ',') AS images
    FROM products p
    LEFT JOIN brands b ON p.brand_id = b.id
    LEFT JOIN categories c ON p.category_id = c.id
    LEFT JOIN models m ON p.model_id = m.id
    LEFT JOIN product_images pi ON pi.product_id = p.id
    WHERE p.id = ?
    GROUP BY 
      p.id, p.name, p.description, p.price, p.discount_percent, 
      p.stock, p.is_featured, p.created_at, b.name, c.name, m.name;
  `;

  db.query(sql, [id], (err, rows) => {
    if (err) return callback(err, null);
    if (rows.length === 0) return callback(null, null);

    const product = rows[0];

    // 🖼 Зураг массив болгоно
    product.images = product.images
      ? product.images.split(",").map((img) => img.trim())
      : [];

    // 🧩 Үзүүлэлтүүд
    const specSql = `
      SELECT sf.name AS field_name, ps.value
      FROM product_specs ps
      JOIN spec_fields sf ON ps.field_id = sf.id
      WHERE ps.product_id = ?;
    `;

    db.query(specSql, [id], (specErr, specRows) => {
      if (specErr) return callback(specErr, null);
      product.specs = specRows || [];
      callback(null, product);
    });
  });
},



 getByCategory: (categoryId, callback) => {
  const sql = `
    SELECT 
      p.id, 
      p.name, 
      p.price, 
      p.stock,
      (p.stock = 0) AS is_out_of_stock,
      p.discount_percent,
      (p.price * (1 - p.discount_percent / 100)) AS discounted_price,
      p.is_featured,
      (
        SELECT pi.image_url 
        FROM product_images pi 
        WHERE pi.product_id = p.id AND pi.is_main = 1 
        LIMIT 1
      ) AS main_image,

      b.name AS brand,
      c.name AS category_name,
      m.name AS model,

      TIMESTAMPDIFF(DAY, p.created_at, NOW()) AS days_since_added

    FROM products p
    LEFT JOIN brands b ON p.brand_id = b.id
    LEFT JOIN categories c ON p.category_id = c.id
    LEFT JOIN models m ON p.model_id = m.id
    WHERE p.category_id = ?
    ORDER BY p.created_at DESC;
  `;
  db.query(sql, [categoryId], callback);
},


  getCategories: (callback) => {
    const sql = "SELECT id, name FROM categories ORDER BY id ASC;";
    db.query(sql, callback);
  },
};

module.exports = Product;
