const express = require("express");
const cors = require("cors");
const dotenv = require("dotenv");

const userRoutes = require("./routes/userRoutes");
const cartRoutes = require("./routes/cartRoutes");
const orderRoutes = require("./routes/orderRoutes");
const addressRoutes = require("./routes/addressRoutes");
const favoriteRoutes = require("./routes/favoriteRoutes")

dotenv.config();
const app = express();

app.use(cors());
app.use(express.json());

// Public хавтсанд хадгалагдсан зураг файлуудыг serve хийх
app.use(express.static("public"));
app.use("/uploads", express.static("uploads"));

//  Routes бүртгэх
app.use("/user", userRoutes);
app.use("/api/products", require("./routes/productRoutes"));
app.use("/api/cart", cartRoutes);
app.use("/api/orders", orderRoutes);
app.use("/api/address", addressRoutes);
app.use("/api/favorites", require("./routes/favoriteRoutes"));


//  Сервер асаах
const PORT = process.env.PORT || 5050;
app.listen(PORT, () => console.log(`✅ Server running on port ${PORT}`));
