import React from "react";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";

// 🧩 Layout
import UserLayout from "./layouts/UserLayout";

// 🧭 Pages
import NotFound from "./pages/NotFound";
import Home from "./pages/user/home";
import Login from "./pages/user/login";
import Register from "./pages/user/register";
import CategoryPage from "./pages/user/category";
import ProductDetail from "./pages/user/ProductDetail";
import CartPage from "./pages/user/CartPage";

// 👤 Profile Pages
import ProfileLayout from "./pages/user/profile/ProfileLayout";
import Info from "./pages/user/profile/Info";
import Orders from "./pages/user/profile/Orders";
import Favorites from "./pages/user/profile/Favorites";
import ProfileIndex from "./pages/user/profile/index";

// 🧠 Context
import { BreadcrumbProvider } from "./context/BreadcrumbContext";

function App() {
  return (
    <BrowserRouter>
      {/* 🧩 Provider нь бүх user хуудсуудыг бүрхэнэ */}
      <BreadcrumbProvider>
        <Routes>
          {/* Redirect root → home */}
          <Route path="/" element={<Navigate to="/user/home" />} />

          {/* Public routes */}
          <Route
            path="/user/login"
            element={
              <UserLayout>
                <Login />
              </UserLayout>
            }
          />
          <Route
            path="/user/register"
            element={
              <UserLayout>
                <Register />
              </UserLayout>
            }
          />
          <Route
            path="/user/cart"
            element={
              <UserLayout>
                <CartPage />
              </UserLayout>
            }
          />

          {/* Main user routes */}
          <Route
            path="/user/home"
            element={
              <UserLayout>
                <Home />
              </UserLayout>
            }
          />
          <Route
            path="/user/category/:id"
            element={
              <UserLayout>
                <CategoryPage />
              </UserLayout>
            }
          />
          <Route
            path="/user/category/:id/brand/:brandName"
            element={
              <UserLayout>
                <CategoryPage />
              </UserLayout>
            }
          />
          <Route
            path="/user/product/:id"
            element={
              <UserLayout>
                <ProductDetail />
              </UserLayout>
            }
          />

          {/* Profile routes */}
          <Route path="/user/profile" element={<ProfileLayout />}>
            <Route index element={<ProfileIndex />} />
            <Route path="info" element={<Info />} />
            <Route path="orders" element={<Orders />} />
            <Route path="favorites" element={<Favorites />} />
          </Route>

          {/* 404 Page */}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BreadcrumbProvider>
    </BrowserRouter>
  );
}

export default App;
